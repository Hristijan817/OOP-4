package vezba04;

public class Main {

	public static void main(String[] args) {
		Avtomobil obj = new Avtomobil("Toyota", "Corolla", 15400, "Bela"); 
		
		System.out.println("Marka: " + obj.getMarka());
		System.out.println("Model: " + obj.getModel());
		System.out.println("Kilometri pred mnozhenje: " + obj.getPominaitnKm());
		System.out.println("Kilometri posle mnozhenje: " + obj.mnozenjeKm(5));
		System.out.println("Boja: " + obj.getBoja());
		
		
	}
	
	
	
	
}

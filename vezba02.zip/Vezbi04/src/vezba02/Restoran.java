package vezba02;

public class Restoran {

	private String ime;
	private String lokacija;
	private String telefon;
	private int brSedishta;
	
	public String getIme() {
		return ime;
	}
	
	public void setIme(String ime) {
		this.ime = ime;
	}
	
	public String getLokacija() {
		return lokacija;
	}
	
	public void setLokacija(String lokacija) {
		this.lokacija = lokacija;
	}
	
	public String getTelefon() {
		return telefon;
	}
	
	public void setTelefon(String Telefon) {
		this.telefon = Telefon;
	}
	
	public int getbrSedishta() {
		return brSedishta;
	}
	
	public void setbrSedishta(int brSedishta) {
		this.brSedishta = brSedishta;
	}
	
	
	
	
}


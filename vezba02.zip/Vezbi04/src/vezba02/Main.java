package vezba02;

public class Main {

	public static void main(String[] args) {
		Restoran rest = new Restoran();
		rest.setIme("Belvedere");
		rest.setLokacija("Bitola");
		rest.setTelefon("047/612-500");
		rest.setbrSedishta(100);
		
		System.out.println("Kontakt: " + rest.getIme());
		System.out.println("Restoran: " + rest.getLokacija());
		System.out.println("Telefon: " + rest.getTelefon());
		System.out.println("Sedishta: " + rest.getbrSedishta());
		
		
		
	}
	
	
	
}

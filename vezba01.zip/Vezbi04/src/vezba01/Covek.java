package vezba01;

public class Covek {
	
	private String firstName;
	private String lastName;
	private String Embg;
	
	public String getfirstName() {
		return firstName;
	}
	
	public void setfirstName (String firstName) {
		this.firstName = firstName;
	}
	
	public String getlastName() {
		return lastName;
	}

	public void setlastName (String lastName) {
		this.lastName = lastName;
	}
	
	public String getEmbg() {
		return Embg;
	}
	
	public void setEmbg (String Embg) {
		this.Embg = Embg;
	}
	
	
}

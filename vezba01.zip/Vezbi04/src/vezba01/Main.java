package vezba01;

public class Main {

	public static void main(String[] args) {
		
		Covek c = new Covek();
		
		c.setfirstName ("Hristijan");
		c.setlastName("Jankulovski");
		c.setEmbg("2410993485003");
		
		System.out.println("Ime: " + c.getfirstName());
		System.out.println("Prezime: " + c.getlastName());
		System.out.println("EMBG: " + c.getEmbg());
		
		
	}
	
	
	
}
